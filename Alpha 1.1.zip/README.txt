Environment Website
Pre-Alpha Version 1.1
This website was made over the days of April 27th and 28th of 2019 during a hackathon. The original developers came up with this idea because they wanted to bring public attention to the fact that the human race is destroying the very enviornment that we live in.
The original webpage presented on the 28th of April 2019 was very basic, with a simple navbar, pictures, and text. The majority of these two days, however, was spent on a recycling game. This game was made by a member of the team and used up much of the time of the team.
The webpage and game were made using HTML, CSS, and JavaScript.
Install Instructions: Unzip all the files from Alpha 1.1.zip and enjoy the webpage and game!
Uninstall Instructions: No special steps required.
Configuration Instructions: No special steps required.
Operation Instructions: Open up index.html and browse our webpage! Be sure to edit and suggest on our GitHub your edits!
Files List: README.txt, END USER AGREEMENT, Alpha 1.1\animals.html, Alpha 1.1\game.js, Alpha 1.1\index.html, Alpha 1.1\menu.html, Alpha 1.1\play.html, Alpha 1.1\stylesheet.css, Alpha 1.1\webpage.html, Alpha 1.1\btlt.zip, Alpha 1.1\css\2.css, Alpha 1.1\game\game.js
Credits: Nicolas, Morgan, Virij, Adem
Acknowlegdements: Lynn University and the team at Hack at Lynn
Contact Infomation: environmentwebpage@gmail.com
This program is given free of charge, but not free of copyright. This software file is copyright � Nicolas Rodriguez 2019.