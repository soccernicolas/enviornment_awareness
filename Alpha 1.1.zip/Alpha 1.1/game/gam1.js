let water;
// let paper;
let xpos, ypos; // Starting position of shape
let score = 0;
let xspeed = 0; // Speed of the shape
let yspeed = 2.2; // Speed of the shape
let life = 3;
let xdirection = 1; // Left or Right
let ydirection = 1; // Top to Bottom
let bottom = 30;

function setup() {
  let cnv = createCanvas(720,400);
  water=loadImage('https://cdn.glitch.com/2f7feb03-1971-4240-9b34-40e70e08ab56%2Fwater.png?1556401752650')
  noStroke();
  frameRate(30);
  fill(250,250,250)
  // Set the starting position of the shape
  xpos = width / 2;
  ypos = 0;
}

function draw() {
  background(102);
  fill(255,255,0)
  var right = rect(500, 400, 120, -120);
  fill(100,255,255);
  var left = rect(100, 400, 120, -120);
  fill(0,0,0)
  textSize(40)
  text("paper", 110, 305,)
  text("plastic", 503, 310)
  text("♻", 145 , 360)
  text("♻", 540 , 360)
text("score: " + score, 50, 50)
text("life: " + life, 300, 50)
image(water, xpos, ypos, 75, 100)
  // Update the position of the shape
  xpos = xpos + xspeed * xdirection;
  ypos = ypos + yspeed * ydirection;
//(water)
{
  // Test to see if the shape exceeds the boundaries of the screen
  if (ypos > height - 100) {
    
    //yes we are at the bottom.now check if we are papter or plastic
    if (xpos >380 && xpos <620)
    {
      score +=1;
    }
    
    if (xpos<380)
    {
      life -=1;
    }
      
    if (life<1)
    {
      text("life: " +life, 300, 50)
      text ("GAME OVER", 360, 200) = true
    }
    ypos = 0;
    xpos = 360;
    xspeed = 0;
  }
}
    if (paper) {
  // Test to see if the shape exceeds the boundaries of the screen
  if (ypos > height - 100) {
    
    //yes we are at the bottom.now check if we are papter or plastic
    if (xpos >100 && xpos <220)
    {
      score +=1;
    }
    number = (random, 1, 100)
    ypos = 0;
    xpos = 360;
    xspeed = 0;
    
    
  }
}

   
    
  // If it does, reverse its direction by multiplying by -1

  // Draw the shape
  //fill(250,250,250)
  //ellipse(xpos, ypos, rad, rad);
  //image(water, xpos, ypos, rad, rad);
  //image (water) || image (paper)
  

}
function keyPressed() {
  let keyIndex = -1;
  if (key == 'a')
  {
    xspeed = -4;
  }
  if (key == 'd')
  {
    xspeed = 4;
  }
  if (key == 's')
  {
    xspeed = 0;
  }
}