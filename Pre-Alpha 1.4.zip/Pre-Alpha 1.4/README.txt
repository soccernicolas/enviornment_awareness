﻿Environment Website
Pre-Alpha Version 1.4
This website was made over the days of April 27th and 28th of 2019 during a hackathon. The original developers came up with this idea because they wanted to bring public attention to the fact that the human race is destroying the very enviornment that we live in.
The original webpage presented on the 28th of April 2019 was very basic, with a simple navbar, pictures, and text. The majority of these two days, however, was spent on a recycling game. This game was made by a member of the team, Adem and used up much of the time of the team.
The webpage and game were made using HTML, CSS, and JavaScript.
Install Instructions: Unzip all the files from Alpha 1.4.zip and enjoy the webpage and game!
Uninstall Instructions: No special steps required.
Configuration Instructions: No special steps required.
Operation Instructions: Open up index.html and browse our webpage! Be sure to edit and suggest on our GitHub your edits!
Credits: Nicolas, Morgan, Virij, Adem
Acknowlegdements: Lynn University and the team at Hack at Lynn.
Contact Infomation: environmentwebpage@gmail.com
This program is given free of charge, but not free of copyright. This software file is copyright © Nicolas Rodriguez 2019. This software is provided "as-is". No warranties, expressed and implied. By downloading this piece of software you consent to hold harmless the creaters of this software for any damages.