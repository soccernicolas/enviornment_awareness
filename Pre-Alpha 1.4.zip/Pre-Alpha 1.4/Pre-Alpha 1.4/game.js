let water;
let paper;
let recycle;
let xpos, ypos; // Starting position of shape
let score = 0;
let xspeed = 0; // Speed of the shape
let yspeed = 2; // Speed of the shape
let life = 3;
let bottom = 30;
let number;

function setup() {
  let cnv = createCanvas(720,400);
  water=loadImage('https://cdn.glitch.com/2f7feb03-1971-4240-9b34-40e70e08ab56%2Fwater.png?1556401752650')
  paper=loadImage('https://cdn.glitch.com/2f7feb03-1971-4240-9b34-40e70e08ab56%2FNewspaper.png?1556408834658')
  recycle=loadImage('https://cdn.glitch.com/2f7feb03-1971-4240-9b34-40e70e08ab56%2Frecycle.png?v=1558967752888')
  noStroke();
  frameRate(30);
  fill(250,250,250)
  // Set the starting position of the shape
  xpos = width / 2;
  ypos = 0;
}
number=Math.random(0,100);
number=Math.round(number);
if (number == 0) {
    console.log("paper")
} else {
    console.log("water")
}
function draw() {
  background(102);
  fill(255,255,0)
  var right = rect(500, 400, 120, -120);
  fill(100,255,255);
  var left = rect(100, 400, 120, -120);
  fill(0,0,0)
  textSize(40)
  text("paper", 503, 305)
  text("plastic", 110, 310)
  image(recycle, 125, 320, 75, 75)
  image(recycle, 525, 320, 75, 75)
text("score: " +score, 50, 50)
text("life: " +life, 300, 50)
image(paper, xpos, ypos, 75, 100)
  // Update the position of the shape
  xpos = xpos + xspeed;
  ypos = ypos + yspeed;
  // Test to see if the shape exceeds the boundaries of the screen
  if (ypos > height - 100) {
    
    //yes we are at the bottom.now check if we are paper or plastic
    if (xpos >380 && xpos <620)
    {
      score +=1;
    }
    
    if (xpos<380)
    {
      life -=1;
    }
      
    if (life<1)
    {
      text("GAME OVER", 360, 200) = true;
    }
    ypos = 0;
    xpos = 360;
    xspeed = 0;
  }
}
function keyPressed() {
  if (key == 'a')
  {
    xspeed = -4;
  }
  if (key == 'd')
  {
    xspeed = 4;
  }
  if (key == 's')
  {
    xspeed = 0;
  }
  if (key == 'x')
  {
    yspeed = yspeed * 2;
  }
  if (key == 'w')
  {
    yspeed = yspeed / 2;
  }
}